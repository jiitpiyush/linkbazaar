<?php
$config['callback_url']=   'http://linkbazaar.in/login/fb/?fbTrue=true'; //   /?fbTrue=true allow you to code process section.

//Facebook configuration
$config['App_ID']      =   '906581126069919';
$config['App_Secret']  =   'e641799588e1b7ea5839723bfb882f87'; 

?>
